/**
 * Created by Lenovo on 3/16/2017.
 */
export class Sort {
  public direction: string;
  public property: string;
}
