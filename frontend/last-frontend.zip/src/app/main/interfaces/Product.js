"use strict";
/**
 * Created by temp on 3/5/2017.
 */
var Product = (function () {
    function Product() {
    }
    return Product;
}());
exports.Product = Product;
