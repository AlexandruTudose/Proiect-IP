/**
 * Created by Daniel on 5/30/2017.
 */
export class Coursetype {
  seminar: string;
  course: string;
  laboratory: string;

  constructor(seminar,course,laboratory) {
    this.seminar = seminar;
    this.course = course;
    this.laboratory = laboratory;
  }
}
