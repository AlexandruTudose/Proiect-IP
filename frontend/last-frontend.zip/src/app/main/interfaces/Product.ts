/**
 * Created by temp on 3/5/2017.
 */
export class Product {
  public id: number;
  public name: string;

  constructor() {
    this.id = 0;
    this.name = "maria";
  }
}
