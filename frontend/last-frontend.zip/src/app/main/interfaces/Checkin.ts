/**
 * Created by Daniel on 5/30/2017.
 */
export class Checkin {
  id: string;
  subject: string;
  classType: string;
  createDate: string;
  numberOfCheckedInUsers: number;
  finishingFlag: boolean;
  userId: string;
}
