
export class UserLog {


  email: string;
  password: string;
}
