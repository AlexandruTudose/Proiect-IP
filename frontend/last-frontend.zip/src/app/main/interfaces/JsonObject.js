"use strict";
/**
 * Created by Lenovo on 3/16/2017.
 */
var JsonObject = (function () {
    function JsonObject() {
    }
    return JsonObject;
}());
exports.JsonObject = JsonObject;
