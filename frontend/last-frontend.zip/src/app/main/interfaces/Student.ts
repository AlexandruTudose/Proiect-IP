/**
 * Created by Daniel on 5/3/2017.
 */
export class Student {

  nume: string;
  prenume: string;
  grupa: string;
  an: number;
  nr_matricoll: number;
  nr_matricol: number;
}
