export class Member {
  public id: number;
  public name: string;
  public username: string;
  public created_at: string;
}
