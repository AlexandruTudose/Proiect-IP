/**
 * Created by Daniel on 4/12/2017.
 */
export class Course {
  public id: number;
  public denumire: string;
  public an: number;
  public credite: number;
}
