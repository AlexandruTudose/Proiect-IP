/**
 * Created by Daniel on 5/3/2017.
 */
export class Teacher {
  id: number;
  id_curs: number;
  nume: string;
  prenume: string;
}
