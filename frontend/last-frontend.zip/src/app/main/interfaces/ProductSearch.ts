/**
 * Created by Lenovo on 3/20/2017.
 */
export class ProductSearch {
  public name: string = "";
  public startsWith: boolean = false;
  public exactMatch: boolean = false;
}

