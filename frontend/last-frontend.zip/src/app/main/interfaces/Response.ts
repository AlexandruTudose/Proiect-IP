/**
 * Created by Daniel on 4/13/2017.
 */
export class Responsee {
  public totalpages: number;
  public totalElements: number;
  constructor() {
    this.totalElements = 10;
    this.totalpages = 5;
  }
}
