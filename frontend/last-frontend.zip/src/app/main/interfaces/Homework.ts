/**
 * Created by Daniel on 4/12/2017.
 */
export class Homework {
  public id: number;
  public id_curs: number;
  public id_student: string;
  public id_nota: number;
  public tip_tema: string;
  public fisier: string;
  public data_predare: Date;
}
