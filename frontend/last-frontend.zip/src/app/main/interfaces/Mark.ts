/**
 * Created by Daniel on 4/12/2017.
 */
export class Mark {
  public id: number;
  public valoare: number;
  public id_profesor: number;
  public data_notare: Date;
}
