
export class User {

  active= true;
  firstName: string;
  lastName: string;
  email: string;
  role: string;
  password: string;
  id: any;
  validated: boolean;
}
