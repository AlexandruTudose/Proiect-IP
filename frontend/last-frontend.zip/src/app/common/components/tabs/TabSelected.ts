/**
 * Created by Daniel on 27.03.2017.
 */
export class TabSelected {
  select: number = 1;

  constructor(selected: number) {
  this.select = selected;
  }
}

